#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/robot_state/robot_state.h>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/wrench_stamped.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <controller_manager_msgs/srv/switch_controller.hpp>
#include <thread>
#include <mutex>
#include <atomic>
#include <map>
#include "ur16e_move_server/action/move_to_pose.hpp"

// TODO: Replace with your actual perception service message types
// #include "open_set_object_detection_msgs/srv/get_object_locations.hpp"
// #include "ur_msgs/srv/set_io.hpp"

using namespace std::chrono_literals;

class SuctionGripperMTP : public rclcpp::Node
{
public:
  using MoveToPose = ur16e_move_server::action::MoveToPose;
  using GoalHandle = rclcpp_action::ServerGoalHandle<MoveToPose>;
  // using GetObjectLocations = open_set_object_detection_msgs::srv::GetObjectLocations;
  // using SetIO = ur_msgs::srv::SetIO;

  SuctionGripperMTP() : Node("suction_gripper_mtp_server")
  {
    // Parameters
    planning_group_ = declare_parameter<std::string>("planning_group", "left_arm");
    end_effector_link_ = declare_parameter<std::string>("end_effector_link", "left_suction_gripper_tcp");
    robot_prefix_ = declare_parameter<std::string>("robot_prefix", "left");
    
    // Motion parameters
    pick_place_height_ = declare_parameter<double>("pick_place_height", 0.3);
    look_height_ = declare_parameter<double>("look_height", 0.23);
    object_clearance_ = declare_parameter<double>("object_clearance", 0.05);
    eef_step_ = declare_parameter<double>("eef_step", 0.005);
    cartesian_min_fraction_ = declare_parameter<double>("cartesian_min_fraction", 0.90);
    
    // Force/Torque parameters
    ft_setpoint_ = declare_parameter<double>("ft_setpoint", 64.0);
    ft_error_allowance_ = declare_parameter<double>("ft_error_allowance", 1.0);
    velocity_z_ = declare_parameter<double>("velocity_z", -0.015);
    ft_control_rate_ = declare_parameter<double>("ft_control_rate", 30.0);
    
    // Gripper IO parameters
    gripper_io_fun_ = declare_parameter<int>("gripper_io_fun", 1);
    gripper_io_pin_ = declare_parameter<int>("gripper_io_pin", 12);
    gripper_activate_state_ = declare_parameter<int>("gripper_activate_state", 1);
    gripper_deactivate_state_ = declare_parameter<int>("gripper_deactivate_state", 0);
    gripper_activation_delay_ = declare_parameter<double>("gripper_activation_delay", 1.0);
    
    // Controller names
    trajectory_controller_ = declare_parameter<std::string>("trajectory_controller", 
                                                            "scaled_pos_joint_traj_controller");
    twist_controller_ = declare_parameter<std::string>("twist_controller", "twist_controller");
    
    // Pre-action pose (optional)
    use_pre_action_pose_ = declare_parameter<bool>("use_pre_action_pose", false);
    
    // Perception offsets (to correct detection errors)
    perception_offset_x_ = declare_parameter<double>("perception_offset_x", -0.01);
    perception_offset_y_ = declare_parameter<double>("perception_offset_y", -0.005);
    
    // Initialize atomic variables
    force_z_.store(0.0);
    have_joint_state_.store(false);
    
    // Subscribers
    js_sub_ = create_subscription<sensor_msgs::msg::JointState>(
      "joint_states", rclcpp::SensorDataQoS(),
      [this](const sensor_msgs::msg::JointState::SharedPtr) {
        have_joint_state_.store(true);
      });
    
    wrench_sub_ = create_subscription<geometry_msgs::msg::WrenchStamped>(
      robot_prefix_ + "/wrench", 10,
      std::bind(&SuctionGripperMTP::wrench_callback, this, std::placeholders::_1));
    
    // Publisher
    twist_pub_ = create_publisher<geometry_msgs::msg::Twist>(
      robot_prefix_ + "/twist_controller/command", 10);
    
    // Service clients
    zero_ft_client_ = create_client<std_srvs::srv::Trigger>(
      robot_prefix_ + "/ur_hardware_interface/zero_ftsensor");
    
    switch_controller_client_ = create_client<controller_manager_msgs::srv::SwitchController>(
      robot_prefix_ + "/controller_manager/switch_controller");
    
    // TODO: Uncomment when you have the actual service types
    // perception_client_ = create_client<GetObjectLocations>(
    //   robot_prefix_ + "_get_object_locations");
    
    // set_io_client_ = create_client<SetIO>(
    //   robot_prefix_ + "/ur_hardware_interface/set_io");
    
    // Action server
    action_server_ = rclcpp_action::create_server<MoveToPose>(
      this, "suction_pick_place",
      std::bind(&SuctionGripperMTP::on_goal, this, std::placeholders::_1, std::placeholders::_2),
      std::bind(&SuctionGripperMTP::on_cancel, this, std::placeholders::_1),
      std::bind(&SuctionGripperMTP::on_accept, this, std::placeholders::_1));
    
    init_timer_ = create_wall_timer(0ms, std::bind(&SuctionGripperMTP::delayed_init, this));
    
    RCLCPP_INFO(get_logger(), "Suction Gripper MTP Server initialized");
  }

private:
  // ROS components
  rclcpp_action::Server<MoveToPose>::SharedPtr action_server_;
  rclcpp::TimerBase::SharedPtr init_timer_;
  std::unique_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;
  std::unique_ptr<moveit::planning_interface::PlanningSceneInterface> psi_;
  
  // Subscribers
  rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr js_sub_;
  rclcpp::Subscription<geometry_msgs::msg::WrenchStamped>::SharedPtr wrench_sub_;
  
  // Publishers
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr twist_pub_;
  
  // Service clients
  rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr zero_ft_client_;
  rclcpp::Client<controller_manager_msgs::srv::SwitchController>::SharedPtr switch_controller_client_;
  // rclcpp::Client<GetObjectLocations>::SharedPtr perception_client_;
  // rclcpp::Client<SetIO>::SharedPtr set_io_client_;
  
  // State variables
  std::atomic<double> force_z_;
  std::atomic<bool> have_joint_state_;
  bool mgi_ready_{false};
  std::mutex exec_mtx_;
  
  // Parameters
  std::string planning_group_, end_effector_link_, robot_prefix_;
  std::string trajectory_controller_, twist_controller_;
  double pick_place_height_, look_height_, object_clearance_;
  double eef_step_, cartesian_min_fraction_;
  double ft_setpoint_, ft_error_allowance_, velocity_z_, ft_control_rate_;
  int gripper_io_fun_, gripper_io_pin_, gripper_activate_state_, gripper_deactivate_state_;
  double gripper_activation_delay_;
  bool use_pre_action_pose_;
  double perception_offset_x_, perception_offset_y_;

  // ========== Utility Functions ==========
  
  void wrench_callback(const geometry_msgs::msg::WrenchStamped::SharedPtr msg)
  {
    force_z_.store(msg->wrench.force.z);
  }
  
  geometry_msgs::msg::Pose shift_pose(const geometry_msgs::msg::Pose& p, 
                                       double dx, double dy, double dz)
  {
    auto out = p;
    out.position.x += dx;
    out.position.y += dy;
    out.position.z += dz;
    return out;
  }
  
  geometry_msgs::msg::Pose make_pose(double x, double y, double z,
                                     const geometry_msgs::msg::Quaternion& orientation)
  {
    geometry_msgs::msg::Pose p;
    p.position.x = x;
    p.position.y = y;
    p.position.z = z;
    p.orientation = orientation;
    return p;
  }
  
  bool wait_for_joint_states(double timeout)
  {
    auto start = std::chrono::steady_clock::now();
    rclcpp::Rate r(100);
    while (rclcpp::ok()) {
      if (have_joint_state_.load()) return true;
      if (std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count() > timeout)
        return false;
      r.sleep();
    }
    return false;
  }
  
  // ========== Controller Management ==========
  
  bool switch_controller(const std::string& start_controller, 
                        const std::string& stop_controller)
  {
    if (!switch_controller_client_->wait_for_service(5s)) {
      RCLCPP_ERROR(get_logger(), "Switch controller service not available");
      return false;
    }
    
    auto request = std::make_shared<controller_manager_msgs::srv::SwitchController::Request>();
    request->start_controllers = {start_controller};
    request->stop_controllers = {stop_controller};
    request->strictness = controller_manager_msgs::srv::SwitchController::Request::STRICT;
    request->start_asap = true;
    request->timeout = rclcpp::Duration(0, 0);
    
    auto future = switch_controller_client_->async_send_request(request);
    
    // 使用wait_for代替spin_until_future_complete避免executor冲突
    using namespace std::chrono_literals;
    auto status = future.wait_for(5s);
    
    if (status != std::future_status::ready) {
      RCLCPP_ERROR(get_logger(), "Failed to call switch controller service - timeout");
      return false;
    }
    
    auto result = future.get();
    if (!result->ok) {
      RCLCPP_ERROR(get_logger(), "Controller switch failed");
      return false;
    }
    
    RCLCPP_INFO(get_logger(), "Switched from %s to %s", 
                stop_controller.c_str(), start_controller.c_str());
    return true;
  }
  
  // ========== Force/Torque Control ==========
  
  bool zero_ft_sensor()
  {
    if (!zero_ft_client_->wait_for_service(2s)) {
      RCLCPP_WARN(get_logger(), "Zero FT sensor service not available");
      return false;
    }
    
    auto request = std::make_shared<std_srvs::srv::Trigger::Request>();
    auto future = zero_ft_client_->async_send_request(request);
    
    // 使用wait_for代替spin_until_future_complete避免executor冲突
    using namespace std::chrono_literals;
    auto status = future.wait_for(2s);
    
    if (status != std::future_status::ready) {
      RCLCPP_WARN(get_logger(), "Failed to zero FT sensor - timeout");
      return false;
    }
    
    auto result = future.get();
    if (!result->success) {
      RCLCPP_WARN(get_logger(), "FT sensor zeroing unsuccessful: %s", result->message.c_str());
      return false;
    }
    
    RCLCPP_INFO(get_logger(), "FT sensor zeroed successfully");
    return true;
  }
  
  bool touch_with_ft_feedback()
  {
    RCLCPP_INFO(get_logger(), "Starting FT feedback touch control");
    
    // 检查twist_controller是否可用
    if (!switch_controller_client_->wait_for_service(1s)) {
      RCLCPP_WARN(get_logger(), "Controller manager not available, skipping FT touch");
      return true;  // 在仿真中跳过，认为成功
    }
    
    // Switch to twist controller
    if (!switch_controller(twist_controller_, trajectory_controller_)) {
      RCLCPP_WARN(get_logger(), "Failed to switch to twist controller, skipping FT touch");
      return true;  // 控制器切换失败时跳过，认为成功
    }
    
    // Zero the FT sensor
    zero_ft_sensor();
    
    rclcpp::Rate rate(ft_control_rate_);
    int stable_count = 0;
    const int stable_threshold = 10;
    int max_iterations = static_cast<int>(10.0 * ft_control_rate_); // 10秒超时
    int iterations = 0;
    
    geometry_msgs::msg::Twist twist_cmd;
    
    while (iterations++ < max_iterations) {
      double error = ft_setpoint_ - force_z_.load();
      
      // Simple proportional control
      if (error > 0) {
        twist_cmd.linear.z = velocity_z_;
        stable_count = 0;  // 重置稳定计数
      } else {
        twist_cmd.linear.z = 0.0;
        stable_count++;
        
        if (stable_count > stable_threshold) {
          RCLCPP_INFO(get_logger(), "Contact achieved, force: %.2f N", force_z_.load());
          break;
        }
      }
      
      twist_pub_->publish(twist_cmd);
      rate.sleep();
    }
    
    if (iterations >= max_iterations) {
      RCLCPP_WARN(get_logger(), "FT touch control timeout");
    }
    
    // Stop motion
    twist_cmd.linear.z = 0.0;
    twist_pub_->publish(twist_cmd);
    
    rclcpp::sleep_for(200ms);
    
    // Switch back to trajectory controller
    if (!switch_controller(trajectory_controller_, twist_controller_)) {
      return false;
    }
    
    return true;
  }
  
  // ========== Gripper Control ==========
  
  bool control_gripper(bool activate)
  {
    // TODO: Uncomment when you have the actual SetIO service
    /*
    if (!set_io_client_->wait_for_service(2s)) {
      RCLCPP_ERROR(get_logger(), "SetIO service not available");
      return false;
    }
    
    auto request = std::make_shared<SetIO::Request>();
    request->fun = gripper_io_fun_;
    request->pin = gripper_io_pin_;
    request->state = activate ? gripper_activate_state_ : gripper_deactivate_state_;
    
    auto future = set_io_client_->async_send_request(request);
    
    if (rclcpp::spin_until_future_complete(shared_from_this(), future, 2s) 
        != rclcpp::FutureReturnCode::SUCCESS) {
      RCLCPP_ERROR(get_logger(), "Failed to call SetIO service");
      return false;
    }
    
    auto result = future.get();
    if (!result->success) {
      RCLCPP_ERROR(get_logger(), "SetIO failed");
      return false;
    }
    */
    
    RCLCPP_INFO(get_logger(), "%s gripper", activate ? "Activating" : "Deactivating");
    rclcpp::sleep_for(std::chrono::nanoseconds(
      static_cast<int64_t>(gripper_activation_delay_ * 1e9)));
    return true;
  }
  
  // ========== Perception ==========
  
  bool get_object_location(const std::string& prompt __attribute__((unused)), 
                           geometry_msgs::msg::Pose& object_pose)
  {
    // TODO: Uncomment when you have the actual perception service
    /*
    if (!perception_client_->wait_for_service(5s)) {
      RCLCPP_ERROR(get_logger(), "Perception service not available");
      return false;
    }
    
    auto request = std::make_shared<GetObjectLocations::Request>();
    request->prompt = prompt;
    
    auto future = perception_client_->async_send_request(request);
    
    if (rclcpp::spin_until_future_complete(shared_from_this(), future, 10s) 
        != rclcpp::FutureReturnCode::SUCCESS) {
      RCLCPP_ERROR(get_logger(), "Perception service call failed");
      return false;
    }
    
    auto result = future.get();
    
    if (result->result.object_position.empty()) {
      RCLCPP_ERROR(get_logger(), "No objects detected");
      return false;
    }
    
    if (result->result.object_position.size() > 1) {
      RCLCPP_WARN(get_logger(), "Multiple objects detected (%zu), using first one", 
                  result->result.object_position.size());
    }
    
    object_pose = result->result.object_position[0].pose.pose;
    RCLCPP_INFO(get_logger(), "Object detected at: [%.3f, %.3f, %.3f]",
                object_pose.position.x, object_pose.position.y, object_pose.position.z);
    */
    
    // Dummy implementation for now
    RCLCPP_WARN(get_logger(), "Perception service not implemented yet, using dummy pose");
    object_pose.position.x = 0.5;
    object_pose.position.y = 0.0;
    object_pose.orientation.w = 1.0;
    
    return true;
  }
  
  // ========== Motion Execution ==========
  
  bool execute_cartesian_path(const std::vector<geometry_msgs::msg::Pose>& waypoints, 
                              const std::string& tag)
  {
    if (waypoints.size() < 2) {
      RCLCPP_WARN(get_logger(), "[%s] Less than 2 waypoints, skipping", tag.c_str());
      return true;
    }
    
    RCLCPP_INFO(get_logger(), "[%s] Executing cartesian path with %zu waypoints", 
                tag.c_str(), waypoints.size());
    
    for (int attempt = 1; attempt <= 3; ++attempt) {
      moveit_msgs::msg::RobotTrajectory trajectory;
      double fraction = move_group_->computeCartesianPath(
        waypoints, eef_step_, 0.0, trajectory, true);
      
      RCLCPP_INFO(get_logger(), "[%s] Cartesian path fraction: %.2f (attempt %d/3)", 
                  tag.c_str(), fraction, attempt);
      
      if (fraction >= cartesian_min_fraction_) {
        // Retime trajectory for velocity scaling
        moveit::planning_interface::MoveGroupInterface::Plan plan;
        plan.trajectory_ = trajectory;
        
        // Execute
        if (move_group_->execute(plan) == moveit::core::MoveItErrorCode::SUCCESS) {
          RCLCPP_INFO(get_logger(), "[%s] Execution successful", tag.c_str());
          return true;
        } else {
          RCLCPP_WARN(get_logger(), "[%s] Execution failed", tag.c_str());
        }
      }
      
      if (attempt < 3) {
        rclcpp::sleep_for(500ms);
      }
    }
    
    RCLCPP_ERROR(get_logger(), "[%s] Failed after 3 attempts", tag.c_str());
    return false;
  }
  
  // ========== Initialization ==========
  
  void delayed_init()
  {
    if (mgi_ready_) return;
    
    move_group_ = std::make_unique<moveit::planning_interface::MoveGroupInterface>(
      shared_from_this(), planning_group_);
    move_group_->setEndEffectorLink(end_effector_link_);
    move_group_->setPlanningTime(10.0);
    move_group_->setNumPlanningAttempts(5);
    move_group_->setMaxVelocityScalingFactor(1.0);
    move_group_->setMaxAccelerationScalingFactor(0.5);
    move_group_->setPlannerId("RRTConnectkConfigDefault");
    move_group_->startStateMonitor();
    
    psi_ = std::make_unique<moveit::planning_interface::PlanningSceneInterface>();
    
    wait_for_joint_states(3.0);
    
    mgi_ready_ = true;
    rclcpp::sleep_for(2s);
    init_timer_->cancel();
    
    RCLCPP_INFO(get_logger(), "MoveIt interface ready");
  }
  
  // ========== Action Server Callbacks ==========
  
  rclcpp_action::GoalResponse on_goal(
    const rclcpp_action::GoalUUID&,
    std::shared_ptr<const MoveToPose::Goal>)
  {
    if (!mgi_ready_ || !exec_mtx_.try_lock()) {
      RCLCPP_WARN(get_logger(), "Rejecting goal - system not ready or busy");
      return rclcpp_action::GoalResponse::REJECT;
    }
    exec_mtx_.unlock();
    return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
  }
  
  rclcpp_action::CancelResponse on_cancel(const std::shared_ptr<GoalHandle>)
  {
    RCLCPP_INFO(get_logger(), "Goal cancellation requested");
    if (move_group_) move_group_->stop();
    return rclcpp_action::CancelResponse::ACCEPT;
  }
  
  void on_accept(const std::shared_ptr<GoalHandle> gh)
  {
    std::thread([this, gh]() { execute_pick_place(gh); }).detach();
  }
  
  // ========== Main Pick and Place Logic ==========
  
  void execute_pick_place(const std::shared_ptr<GoalHandle> gh)
  {
    std::lock_guard<std::mutex> lk(exec_mtx_);
    auto result = std::make_shared<MoveToPose::Result>();
    auto goal = gh->get_goal();
    
    try {
      if (!move_group_ || gh->is_canceling()) {
        throw std::runtime_error("System not ready or canceled");
      }
      
      if (!wait_for_joint_states(2.0)) {
        throw std::runtime_error("No joint states received");
      }
      
      // Extract goal information
      auto start_pose = goal->target_pose.pose;
      // TODO: Extract prompt and destination from goal if needed
      // For now, we assume the goal only contains the pick location
      
      RCLCPP_INFO(get_logger(), "=== Starting Pick and Place Sequence ===");
      RCLCPP_INFO(get_logger(), "Pick location: [%.3f, %.3f, %.3f]",
                  start_pose.position.x, start_pose.position.y, start_pose.position.z);
      
      // ========== Step 1: Move to Pre-Pick Position ==========
      RCLCPP_INFO(get_logger(), "Step 1: Moving to pre-pick position");
      
      std::vector<geometry_msgs::msg::Pose> waypoints;
      auto current_pose = move_group_->getCurrentPose().pose;
      
      auto prepick = shift_pose(start_pose, 0.0, 0.1, pick_place_height_ - start_pose.position.z);
      
      // Check if we need to go through an intermediate "origin" pose
      if (prepick.position.x > 0 && prepick.position.y > 0) {
        auto origin = make_pose(0.0, 0.20, pick_place_height_, prepick.orientation);
        waypoints = {current_pose, origin, prepick};
      } else {
        waypoints = {current_pose, prepick};
      }
      
      if (!execute_cartesian_path(waypoints, "Pre-pick")) {
        throw std::runtime_error("Failed to reach pre-pick position");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 2: Move Closer for Perception ==========
      RCLCPP_INFO(get_logger(), "Step 2: Moving closer for perception");
      
      current_pose = move_group_->getCurrentPose().pose;
      auto look_pose = prepick;
      look_pose.position.z = look_height_;
      
      waypoints = {current_pose, look_pose};
      
      if (!execute_cartesian_path(waypoints, "Look")) {
        throw std::runtime_error("Failed to reach look position");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 3: Call Perception ==========
      RCLCPP_INFO(get_logger(), "Step 3: Calling perception service");
      
      geometry_msgs::msg::Pose detected_object_pose;
      if (!get_object_location("target_object", detected_object_pose)) {
        throw std::runtime_error("Perception failed");
      }
      
      // ========== Step 4: Move to Pick Position with Offsets ==========
      RCLCPP_INFO(get_logger(), "Step 4: Moving to pick position");
      
      current_pose = move_group_->getCurrentPose().pose;
      
      auto pick_pose = detected_object_pose;
      pick_pose.position.x += perception_offset_x_;
      pick_pose.position.y += perception_offset_y_;
      pick_pose.position.z += object_clearance_;
      pick_pose.orientation = start_pose.orientation;  // Keep desired orientation
      
      auto correction_pose = pick_pose;
      correction_pose.position.z = current_pose.position.z;
      
      waypoints = {current_pose, correction_pose, pick_pose};
      
      if (!execute_cartesian_path(waypoints, "Pick approach")) {
        throw std::runtime_error("Failed to reach pick position");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 5: Touch with FT Feedback ==========
      RCLCPP_INFO(get_logger(), "Step 5: Touching object with force feedback");
      
      if (!touch_with_ft_feedback()) {
        RCLCPP_WARN(get_logger(), "FT feedback touch failed, continuing anyway");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 6: Activate Gripper ==========
      RCLCPP_INFO(get_logger(), "Step 6: Activating gripper");
      
      if (!control_gripper(true)) {
        throw std::runtime_error("Failed to activate gripper");
      }
      
      // ========== Step 7: Lift Object ==========
      RCLCPP_INFO(get_logger(), "Step 7: Lifting object");
      
      current_pose = move_group_->getCurrentPose().pose;
      waypoints = {current_pose, correction_pose};
      
      if (!execute_cartesian_path(waypoints, "Lift")) {
        throw std::runtime_error("Failed to lift object");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 8: Move to Pre-Place Position ==========
      RCLCPP_INFO(get_logger(), "Step 8: Moving to pre-place position");
      
      // TODO: Get actual place location from goal
      auto place_pose = make_pose(0.3, -0.3, 0.01, start_pose.orientation);
      auto preplace = shift_pose(place_pose, 0.0, 0.0, pick_place_height_ - place_pose.position.z);
      
      waypoints.clear();
      
      // Check if we need to go through origin
      if (pick_pose.position.x > 0 && pick_pose.position.y > 0) {
        auto origin = make_pose(0.0, 0.2, pick_place_height_, preplace.orientation);
        waypoints.push_back(origin);
      }
      waypoints.push_back(preplace);
      
      if (!execute_cartesian_path(waypoints, "Pre-place")) {
        throw std::runtime_error("Failed to reach pre-place position");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 9: Lower to Place Position ==========
      RCLCPP_INFO(get_logger(), "Step 9: Lowering to place position");
      
      waypoints = {preplace, place_pose};
      
      if (!execute_cartesian_path(waypoints, "Place")) {
        throw std::runtime_error("Failed to reach place position");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 10: Deactivate Gripper ==========
      RCLCPP_INFO(get_logger(), "Step 10: Deactivating gripper");
      
      if (!control_gripper(false)) {
        RCLCPP_WARN(get_logger(), "Failed to deactivate gripper");
      }
      
      // ========== Step 11: Retract ==========
      RCLCPP_INFO(get_logger(), "Step 11: Retracting");
      
      current_pose = move_group_->getCurrentPose().pose;
      waypoints = {current_pose, preplace};
      
      if (!execute_cartesian_path(waypoints, "Retract")) {
        RCLCPP_WARN(get_logger(), "Failed to retract properly");
      }
      rclcpp::sleep_for(200ms);
      
      // ========== Step 12: Return to Pre-Action Position ==========
      RCLCPP_INFO(get_logger(), "Step 12: Returning to pre-action position");
      
      // Use joint space planning to return to pre-action pose
      // This matches the initial ready position for consistent behavior
      std::vector<double> pre_action_joint_values = {
        1.20110777344728,      // shoulder_pan_joint
        -1.5901812058332483,   // shoulder_lift_joint
        1.4020975961789934,    // elbow_joint
        -1.3838437395893834,   // wrist_1_joint
        4.713395037963343,     // wrist_2_joint
        -0.36870762683331165   // wrist_3_joint
      };
      move_group_->setJointValueTarget(pre_action_joint_values);
      
      moveit::planning_interface::MoveGroupInterface::Plan return_plan;
      if (move_group_->plan(return_plan) == moveit::core::MoveItErrorCode::SUCCESS) {
        if (move_group_->execute(return_plan) == moveit::core::MoveItErrorCode::SUCCESS) {
          RCLCPP_INFO(get_logger(), "Returned to pre-action position");
        } else {
          RCLCPP_WARN(get_logger(), "Failed to execute return to pre-action position");
        }
      } else {
        RCLCPP_WARN(get_logger(), "Failed to plan return to pre-action position");
      }
      
      // Success!
      RCLCPP_INFO(get_logger(), "=== Pick and Place Completed Successfully ===");
      result->result = true;
      gh->succeed(result);
      
    } catch (const std::exception& e) {
      RCLCPP_ERROR(get_logger(), "Pick and place failed: %s", e.what());
      result->result = false;
      gh->abort(result);
      
      if (move_group_) {
        move_group_->stop();
        move_group_->clearPoseTargets();
      }
    }
  }
};

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<SuctionGripperMTP>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
