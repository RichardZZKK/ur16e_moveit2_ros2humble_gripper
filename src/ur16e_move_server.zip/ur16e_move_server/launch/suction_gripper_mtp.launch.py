from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    
    # Declare arguments
    robot_prefix_arg = DeclareLaunchArgument(
        'robot_prefix',
        default_value='left',
        description='Robot namespace prefix (left or right)'
    )
    
    planning_group_arg = DeclareLaunchArgument(
        'planning_group',
        default_value='left_arm',
        description='MoveIt planning group name'
    )
    
    end_effector_link_arg = DeclareLaunchArgument(
        'end_effector_link',
        default_value='left_suction_gripper_tcp',
        description='End effector link name'
    )
    
    # Configuration
    robot_prefix = LaunchConfiguration('robot_prefix')
    planning_group = LaunchConfiguration('planning_group')
    end_effector_link = LaunchConfiguration('end_effector_link')
    
    # Suction Gripper MTP Node
    suction_gripper_mtp_node = Node(
        package='ur16e_move_server',
        executable='suction_gripper_mtp_server',
        name='suction_gripper_mtp_server',
        output='screen',
        parameters=[{
            'robot_prefix': robot_prefix,
            'planning_group': planning_group,
            'end_effector_link': end_effector_link,
            
            # Motion parameters
            'pick_place_height': 0.3,
            'look_height': 0.23,
            'object_clearance': 0.05,
            'eef_step': 0.005,
            'cartesian_min_fraction': 0.90,
            
            # Force/Torque parameters
            'ft_setpoint': 64.0,
            'ft_error_allowance': 1.0,
            'velocity_z': -0.015,
            'ft_control_rate': 30.0,
            
            # Gripper IO parameters
            'gripper_io_fun': 1,
            'gripper_io_pin': 12,
            'gripper_activate_state': 1,
            'gripper_deactivate_state': 0,
            'gripper_activation_delay': 1.0,
            
            # Controller names
            'trajectory_controller': 'scaled_pos_joint_traj_controller',
            'twist_controller': 'twist_controller',
            
            # Pre-action pose
            'use_pre_action_pose': False,
            
            # Perception correction offsets
            'perception_offset_x': -0.01,
            'perception_offset_y': -0.005,
        }],
        remappings=[
            ('joint_states', '/joint_states'),
        ]
    )
    
    return LaunchDescription([
        robot_prefix_arg,
        planning_group_arg,
        end_effector_link_arg,
        suction_gripper_mtp_node,
    ])
