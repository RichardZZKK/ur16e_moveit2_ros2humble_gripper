#!/usr/bin/env python3
"""
Suction Gripper MTP Bringup Launch File for Real Robot
用于真机测试的启动文件
"""
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
import os
import yaml
import xacro

def generate_launch_description():
    # Declare arguments
    robot_ip_arg = DeclareLaunchArgument(
        'robot_ip',
        default_value='192.168.1.100',
        description='Robot IP address (MUST CHANGE for real robot)'
    )
    
    launch_rviz_arg = DeclareLaunchArgument(
        'launch_rviz',
        default_value='false',
        description='Launch RViz (usually false for real robot)'
    )
    
    robot_prefix_arg = DeclareLaunchArgument(
        'robot_prefix',
        default_value='',
        description='Robot namespace prefix (e.g., "left" for dual arm)'
    )
    
    # Get launch configurations
    robot_ip = LaunchConfiguration('robot_ip')
    launch_rviz = LaunchConfiguration('launch_rviz')
    robot_prefix = LaunchConfiguration('robot_prefix')
    
    # ========== UR Control ==========
    ur_control = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([FindPackageShare("ur_robot_driver"), "launch", "ur_control.launch.py"])
        ]),
        launch_arguments={
            "ur_type": "ur16e",
            "robot_ip": robot_ip,
            "use_fake_hardware": "false",  # Real hardware
            "initial_joint_controller": "scaled_pos_joint_traj_controller",
            "activate_joint_controller": "true",
            "launch_dashboard_client": "true",
            "description_file": PathJoinSubstitution([
                FindPackageShare('ur16e_with_gripper_description'), 'urdf', 'ur16e_with_suction_gripper.xacro'
            ]),
        }.items()
    )
    
    # ========== MoveIt ==========
    moveit = TimerAction(
        period=3.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([FindPackageShare("ur_moveit_config"), "launch", "ur_moveit.launch.py"])
                ]),
                launch_arguments={
                    "ur_type": "ur16e",
                    "launch_rviz": launch_rviz,
                    "use_sim_time": "false",
                    "description_file": PathJoinSubstitution([
                        FindPackageShare('ur16e_with_gripper_description'), 'urdf', 'ur16e_with_suction_gripper.xacro'
                    ]),
                }.items()
            )
        ]
    )
    
    # ========== Robot Description for Action Server ==========
    ur_type = "ur16e"
    
    # Load kinematics
    ur_moveit_pkg = get_package_share_directory("ur_moveit_config")
    kinematics_yaml_path = os.path.join(ur_moveit_pkg, "config", "kinematics.yaml")
    
    with open(kinematics_yaml_path, "r") as f:
        kinematics_yaml = yaml.safe_load(f)
    
    robot_description_kinematics = {
        "robot_description_kinematics": {
            "ur_manipulator": {
                "kinematics_solver": "kdl_kinematics_plugin/KDLKinematicsPlugin",
                "kinematics_solver_attempts": 3,
                "kinematics_solver_search_resolution": 0.005,
                "kinematics_solver_timeout": 0.005,
            }
        }
    }
    
    # ========== Suction Gripper MTP Server ==========
    suction_gripper_server = TimerAction(
        period=5.0,  # Wait for MoveIt and robot to be ready
        actions=[
            Node(
                package="ur16e_move_server",
                executable="suction_gripper_mtp_server",
                name="suction_gripper_mtp_server",
                output="screen",
                parameters=[
                    {
                        # Basic configuration
                        "robot_prefix": robot_prefix,
                        "planning_group": "ur_manipulator",
                        "end_effector_link": "rws_gripper_tcp",  # 修改为实际的link名称
                        
                        # Motion parameters
                        "pick_place_height": 0.30,
                        "look_height": 0.23,
                        "object_clearance": 0.05,
                        "eef_step": 0.005,
                        "cartesian_min_fraction": 0.90,
                        
                        # Force/Torque parameters (REAL ROBOT)
                        "ft_setpoint": 64.0,
                        "ft_error_allowance": 1.0,
                        "velocity_z": -0.015,
                        "ft_control_rate": 30.0,
                        
                        # Gripper IO parameters (REAL ROBOT)
                        "gripper_io_fun": 1,
                        "gripper_io_pin": 12,
                        "gripper_activate_state": 1,
                        "gripper_deactivate_state": 0,
                        "gripper_activation_delay": 1.0,
                        
                        # Controller names (REAL ROBOT)
                        "trajectory_controller": "scaled_pos_joint_traj_controller",
                        "twist_controller": "twist_controller",
                        
                        # Pre-action pose
                        "use_pre_action_pose": False,
                        
                        # Perception correction offsets
                        "perception_offset_x": -0.01,
                        "perception_offset_y": -0.005,
                        
                        # Real robot mode
                        "use_sim_time": False,
                    },
                    robot_description_kinematics,
                ],
            )
        ]
    )
    
    return LaunchDescription([
        # Arguments
        robot_ip_arg,
        launch_rviz_arg,
        robot_prefix_arg,
        
        # Nodes
        ur_control,
        moveit,
        suction_gripper_server,
    ])
