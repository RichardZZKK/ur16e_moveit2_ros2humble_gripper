from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    """Launch file for testing MoveIt configuration with RViz"""
    
    # Declare arguments
    use_fake_hardware_arg = DeclareLaunchArgument(
        'use_fake_hardware',
        default_value='true',
        description='Use fake hardware for testing'
    )
    
    use_fake_hardware = LaunchConfiguration('use_fake_hardware')
    
    # Include move_group launch
    move_group_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('dual_arm_moveit_config'),
                'launch',
                'move_group.launch.py'
            ])
        ]),
        launch_arguments={
            'use_fake_hardware': use_fake_hardware,
        }.items()
    )
    
    # RViz configuration file
    rviz_config_file = PathJoinSubstitution([
        FindPackageShare('dual_arm_moveit_config'),
        'config',
        'moveit.rviz'
    ])
    
    # RViz node
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_file],
        parameters=[{
            'use_sim_time': False,
        }],
    )
    
    return LaunchDescription([
        use_fake_hardware_arg,
        move_group_launch,
        rviz_node,
    ])