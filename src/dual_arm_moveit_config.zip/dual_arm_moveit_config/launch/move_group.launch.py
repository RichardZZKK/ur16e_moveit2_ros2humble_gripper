from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch.conditions import IfCondition
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue  # ← 添加这个
import os
from ament_index_python.packages import get_package_share_directory


def load_yaml(package_name, file_path):
    """Load yaml file from package"""
    package_path = get_package_share_directory(package_name)
    absolute_file_path = os.path.join(package_path, file_path)
    
    try:
        with open(absolute_file_path, 'r') as file:
            return file.read()
    except EnvironmentError:
        return None


def launch_setup(context, *args, **kwargs):
    """Setup function for dynamic launch"""
    
    # Get parameters
    use_fake_hardware = LaunchConfiguration('use_fake_hardware').perform(context)
    
    # Package paths
    moveit_config_pkg = 'dual_arm_moveit_config'
    
    # ========== URDF 从同一个包的 config 目录读取 ==========
    urdf_file = PathJoinSubstitution([
        FindPackageShare(moveit_config_pkg),
        'config',
        'dual_arm.urdf'
    ])
    
    # ← 关键：用 ParameterValue 包装，指定为 str 类型
    robot_description_content = ParameterValue(
        Command(['cat ', urdf_file]),
        value_type=str
    )
    # =====================================================
    
    robot_description = {'robot_description': robot_description_content}
    
    # SRDF file path
    srdf_file = PathJoinSubstitution([
        FindPackageShare(moveit_config_pkg),
        'config',
        'dual_arm.srdf'
    ])
    
    # ← 同样用 ParameterValue 包装
    robot_description_semantic_content = ParameterValue(
        Command(['cat ', srdf_file]),
        value_type=str
    )
    
    robot_description_semantic = {
        'robot_description_semantic': robot_description_semantic_content
    }
    
    # Kinematics yaml
    kinematics_yaml = load_yaml(
        moveit_config_pkg,
        'config/kinematics.yaml'
    )
    robot_description_kinematics = {
        'robot_description_kinematics': kinematics_yaml
    }
    
    # Joint limits yaml
    joint_limits_yaml = load_yaml(
        moveit_config_pkg,
        'config/joint_limits.yaml'
    )
    robot_description_planning = {
        'robot_description_planning': joint_limits_yaml
    }
    
    # Planning pipeline yaml
    ompl_planning_yaml = load_yaml(
        moveit_config_pkg,
        'config/ompl_planning.yaml'
    )
    ompl_planning_pipeline_config = {
        'move_group': {
            'planning_plugin': 'ompl_interface/OMPLPlanner',
            'request_adapters': 'default_planner_request_adapters/AddTimeOptimalParameterization default_planner_request_adapters/ResolveConstraintFrames default_planner_request_adapters/FixWorkspaceBounds default_planner_request_adapters/FixStartStateBounds default_planner_request_adapters/FixStartStateCollision default_planner_request_adapters/FixStartStatePathConstraints',
            'start_state_max_bounds_error': 0.1,
        }
    }
    
    # Trajectory execution config
    trajectory_execution = {
        'moveit_manage_controllers': True,
        'trajectory_execution.allowed_execution_duration_scaling': 1.2,
        'trajectory_execution.allowed_goal_duration_margin': 0.5,
        'trajectory_execution.allowed_start_tolerance': 0.01,
    }
    
    # Planning scene monitor config
    planning_scene_monitor_parameters = {
        'publish_planning_scene': True,
        'publish_geometry_updates': True,
        'publish_state_updates': True,
        'publish_transforms_updates': True,
    }
    
    # Controllers yaml
    moveit_controllers_yaml = load_yaml(
        moveit_config_pkg,
        'config/moveit_controllers.yaml'
    )
    moveit_controllers = {
        'moveit_simple_controller_manager': moveit_controllers_yaml,
        'moveit_controller_manager': 'moveit_simple_controller_manager/MoveItSimpleControllerManager',
    }
    
    # Combine all parameters
    move_group_params = [
        robot_description,
        robot_description_semantic,
        robot_description_kinematics,
        robot_description_planning,
        ompl_planning_pipeline_config,
        trajectory_execution,
        moveit_controllers,
        planning_scene_monitor_parameters,
        {'use_sim_time': False},
    ]
    
    # Move group node
    move_group_node = Node(
        package='moveit_ros_move_group',
        executable='move_group',
        output='screen',
        parameters=move_group_params,
    )
    
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description],
    )
    
    # ROS 2 Control Node (fake or real)
    ros2_control_node = Node(
        package='controller_manager',
        executable='ros2_control_node',
        parameters=[robot_description, {
            'use_sim_time': False,
        }],
        output='screen',
        condition=IfCondition(use_fake_hardware),
    )
    
    # Joint State Broadcaster
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager'],
        output='screen',
    )
    
    # Left arm controller spawner
    left_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['left_joint_trajectory_controller', '-c', '/controller_manager'],
        output='screen',
    )
    
    # Right arm controller spawner
    right_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['right_joint_trajectory_controller', '-c', '/controller_manager'],
        output='screen',
    )
    
    nodes_to_start = [
        robot_state_publisher,
        ros2_control_node,
        joint_state_broadcaster_spawner,
        left_controller_spawner,
        right_controller_spawner,
        move_group_node,
    ]
    
    return nodes_to_start


def generate_launch_description():
    """Generate launch description"""
    
    declared_arguments = []
    
    declared_arguments.append(
        DeclareLaunchArgument(
            'use_fake_hardware',
            default_value='true',
            description='Use fake hardware (simulation) or real hardware',
        )
    )
    
    return LaunchDescription(
        declared_arguments + [OpaqueFunction(function=launch_setup)]
    )
